# Staffora FiveM Plugin v3

## Installation
1. Ordner `staffora` nach `resources/[staffora]/staffora` kopieren
2. `server.cfg`:
   ```
   set staffora_api_url "https://staffora.apps.bot-hosting.cloud"
   set staffora_setup_code "DEIN_CODE_VOM_TEAM_PANEL"
   ensure staffora
   ```
3. Server neu starten — API-Key wird automatisch gespeichert

## Commands (Ingame)
| Command | Beschreibung |
|---------|--------------|
| `/aduty` | Staff Duty an/aus (Uniform + Nametag + F9) |
| `F9` / `F10` | Staff-Menü (nur on-duty) |
| `/support [grund]` | Support-Anfrage an Discord |
| `/stafforalink CODE` | Discord verknüpfen |
| `/verify CODE` | Verify + Whitelist |
| `/sannounce text` | Server-Announce (Permission) |
| `/skick /sban /swarn [id]` | Moderation |
| `/sgoto /sbring [id]` | Teleport |
| `/sfreeze /sunfreeze /srevive /sheal /sspectate [id]` | Tools |

## F9 Panel
- Spielerliste (★ = on duty)
- Goto / Bring / Freeze / Heal / Spectate / Slap / Warn / Kick / Ban
- Noclip · Godmode · Self-Heal · IDs

## Console
- `staffora_hb` — Heartbeat manuell
- `staffora_status` — Status print
