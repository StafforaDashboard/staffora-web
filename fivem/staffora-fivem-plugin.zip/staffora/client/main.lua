--[[ Staffora FiveM Plugin — Client v3 · F9 Staff Panel ]]

local onDuty, rankId, rankLabel = false, nil, nil
local dutyStaff = {}
local menuOpen, mode, menuIndex = false, 'main', 1
local players, selectedPlayer = {}, nil
local spectating, noclip, godmode = false, false, false
local savedClothes = nil
local showIds = false

local function notify(msg)
  BeginTextCommandThefeedDisplay('STRING')
  AddTextComponentSubstringPlayerName('~r~Staffora~s~: ' .. tostring(msg))
  EndTextCommandThefeedDisplay()
end

RegisterNetEvent('staffora:notify', function(msg)
  notify(msg)
end)

local function isMalePed(ped)
  return GetEntityModel(ped) == GetHashKey('mp_m_freemode_01')
end

local function saveClothes(ped)
  savedClothes = {}
  for i = 0, 11 do
    savedClothes[i] = {
      d = GetPedDrawableVariation(ped, i),
      t = GetPedTextureVariation(ped, i)
    }
  end
end

local function restoreClothes(ped)
  if not savedClothes then return end
  for i, v in pairs(savedClothes) do
    SetPedComponentVariation(ped, i, v.d, v.t, 0)
  end
end

local function applyStaffUniform(ped)
  local list = isMalePed(ped) and (Config.Uniforms and Config.Uniforms.male) or (Config.Uniforms and Config.Uniforms.female)
  if not list then return end
  for _, c in ipairs(list) do
    SetPedComponentVariation(ped, c.component, c.drawable, c.texture or 0, 0)
  end
end

local function labelForRank(rank)
  if Config.RankLabels and Config.RankLabels[rank] then return Config.RankLabels[rank] end
  return tostring(rank or 'STAFF'):upper()
end

local function colorForRank(rank)
  local c = Config.RankColors and Config.RankColors[rank]
  if c then return c[1], c[2], c[3] end
  return 239, 68, 68
end

RegisterNetEvent('staffora:duty', function(duty, rank)
  onDuty = duty and true or false
  rankId = rank
  rankLabel = labelForRank(rank)
  local ped = PlayerPedId()
  if onDuty then
    saveClothes(ped)
    applyStaffUniform(ped)
  else
    restoreClothes(ped)
    if noclip then
      noclip = false
      SetEntityCollision(ped, true, true)
      FreezeEntityPosition(ped, false)
      SetEntityVisible(ped, true, false)
    end
    godmode = false
    SetEntityInvincible(ped, false)
    menuOpen = false
  end
end)

RegisterNetEvent('staffora:dutySync', function(list)
  dutyStaff = list or {}
end)

RegisterNetEvent('staffora:teleport', function(x, y, z)
  local ped = PlayerPedId()
  SetEntityCoords(ped, x + 0.0, y + 0.0, z + 0.0, false, false, false, false)
end)

RegisterNetEvent('staffora:freeze', function(state)
  FreezeEntityPosition(PlayerPedId(), state and true or false)
end)

RegisterNetEvent('staffora:heal', function()
  local ped = PlayerPedId()
  local maxH = GetEntityMaxHealth(ped)
  SetEntityHealth(ped, maxH)
  ClearPedBloodDamage(ped)
  SetPedArmour(ped, 100)
end)

RegisterNetEvent('staffora:armor', function()
  SetPedArmour(PlayerPedId(), 100)
end)

RegisterNetEvent('staffora:slap', function()
  local ped = PlayerPedId()
  SetEntityHealth(ped, math.max(101, GetEntityHealth(ped) - 20))
  ApplyForceToEntity(ped, 1, 0.0, 0.0, 8.0, 0.0, 0.0, 0.0, 0, false, true, true, false, true)
end)

RegisterNetEvent('staffora:spectate', function(targetId)
  local tid = GetPlayerFromServerId(tonumber(targetId))
  if tid == -1 then return end
  local tped = GetPlayerPed(tid)
  if not DoesEntityExist(tped) then return end
  spectating = not spectating
  if spectating then
    NetworkSetInSpectatorMode(true, tped)
    notify('Spectate AN')
  else
    NetworkSetInSpectatorMode(false, PlayerPedId())
    notify('Spectate AUS')
  end
end)

RegisterNetEvent('staffora:selfToggle', function(what)
  local ped = PlayerPedId()
  if what == 'noclip' then
    noclip = not noclip
    SetEntityCollision(ped, not noclip, not noclip)
    FreezeEntityPosition(ped, noclip)
    SetEntityVisible(ped, not noclip, false)
    notify(noclip and 'Noclip AN' or 'Noclip AUS')
  elseif what == 'god' then
    godmode = not godmode
    SetEntityInvincible(ped, godmode)
    notify(godmode and 'Godmode AN' or 'Godmode AUS')
  end
end)

RegisterNetEvent('staffora:playerList', function(list)
  players = list or {}
end)

RegisterNetEvent('staffora:announce', function(msg)
  BeginTextCommandThefeedDisplay('STRING')
  AddTextComponentSubstringPlayerName('~b~[ANNOUNCE]~s~ ' .. tostring(msg))
  EndTextCommandThefeedDisplay()
  -- big subtitle
  ClearPrints()
  BeginTextCommandPrint('STRING')
  AddTextComponentSubstringPlayerName(tostring(msg))
  EndTextCommandPrint(6000, true)
end)

local function drawTxt(x, y, scale, text, r, g, b)
  SetTextFont(4)
  SetTextScale(scale, scale)
  SetTextColour(r or 255, g or 255, b or 255, 230)
  SetTextOutline()
  SetTextCentre(false)
  BeginTextCommandDisplayText('STRING')
  AddTextComponentSubstringPlayerName(tostring(text))
  EndTextCommandDisplayText(x, y)
end

local function drawText3D(x, y, z, text, r, g, b)
  local onScreen, sx, sy = World3dToScreen2d(x, y, z)
  if not onScreen then return end
  local cam = GetGameplayCamCoords()
  local dist = #(cam - vector3(x, y, z))
  local scale = (Config.NametagScale or 0.35) / math.max(dist * 0.12, 0.4)
  SetTextScale(scale, scale)
  SetTextFont(4)
  SetTextProportional(true)
  SetTextColour(r or 239, g or 68, b or 68, 255)
  SetTextOutline()
  SetTextCentre(true)
  BeginTextCommandDisplayText('STRING')
  AddTextComponentSubstringPlayerName(tostring(text))
  EndTextCommandDisplayText(sx, sy)
end

-- Nametags for on-duty staff
CreateThread(function()
  while true do
    local sleep = 500
    local myPed = PlayerPedId()
    local myCoords = GetEntityCoords(myPed)
    local maxDist = Config.NametagDistance or 28.0

    if onDuty then
      sleep = 0
      local c = GetEntityCoords(myPed)
      local r, g, b = colorForRank(rankId)
      drawText3D(c.x, c.y, c.z + 1.15, rankLabel or 'STAFF', r, g, b)
    end

    for sid, info in pairs(dutyStaff) do
      local player = GetPlayerFromServerId(tonumber(sid))
      if player ~= -1 then
        local ped = GetPlayerPed(player)
        if DoesEntityExist(ped) and ped ~= myPed then
          local c = GetEntityCoords(ped)
          if #(myCoords - c) < maxDist then
            sleep = 0
            local r, g, b = colorForRank(info.rankId)
            drawText3D(c.x, c.y, c.z + 1.15, info.label or 'STAFF', r, g, b)
            drawText3D(c.x, c.y, c.z + 1.0, info.name or '', 220, 220, 220)
          end
        end
      end
    end

    -- optional player IDs overhead
    if showIds then
      sleep = 0
      for _, pid in ipairs(GetActivePlayers()) do
        local ped = GetPlayerPed(pid)
        if DoesEntityExist(ped) then
          local c = GetEntityCoords(ped)
          if #(myCoords - c) < 40.0 then
            local sid = GetPlayerServerId(pid)
            drawText3D(c.x, c.y, c.z + 0.9, ('ID %s'):format(sid), 180, 180, 255)
          end
        end
      end
    end

    Wait(sleep)
  end
end)

-- Noclip movement
CreateThread(function()
  while true do
    Wait(0)
    if not noclip then
      Wait(300)
    else
      local ped = PlayerPedId()
      local c = GetEntityCoords(ped)
      local speed = IsControlPressed(0, 21) and 3.5 or 1.2
      local camRot = GetGameplayCamRot(2)
      local heading = math.rad(camRot.z)
      local pitch = math.rad(camRot.x)
      local dx = -math.sin(heading) * speed
      local dy = math.cos(heading) * speed
      local dz = math.sin(pitch) * speed
      if IsControlPressed(0, 32) then -- W
        c = vector3(c.x + dx, c.y + dy, c.z + dz)
      end
      if IsControlPressed(0, 33) then -- S
        c = vector3(c.x - dx, c.y - dy, c.z - dz)
      end
      if IsControlPressed(0, 22) then -- Space up
        c = vector3(c.x, c.y, c.z + speed)
      end
      if IsControlPressed(0, 36) then -- Ctrl down
        c = vector3(c.x, c.y, c.z - speed)
      end
      SetEntityCoordsNoOffset(ped, c.x, c.y, c.z, true, true, true)
    end
  end
end)

-- Death report
CreateThread(function()
  local wasDead = false
  while true do
    Wait(500)
    local ped = PlayerPedId()
    local dead = IsEntityDead(ped) or IsPedDeadOrDying(ped, true)
    if dead and not wasDead then
      local killer = GetPedSourceOfDeath(ped)
      local kid = nil
      if killer and IsEntityAPed(killer) and IsPedAPlayer(killer) then
        kid = GetPlayerServerId(NetworkGetPlayerIndexFromPed(killer))
      end
      TriggerServerEvent('staffora:playerDied', kid, GetPedCauseOfDeath(ped))
    end
    wasDead = dead
  end
end)

-- ─── F9 Staff Menu ───────────────────────────────────────────
local mainItems = {
  { label = '👥 Spieler', action = 'players' },
  { label = '👻 Noclip', action = 'noclip' },
  { label = '🛡️ Godmode', action = 'god' },
  { label = '❤️ Self Heal', action = 'selfheal' },
  { label = '🔢 IDs an/aus', action = 'ids' },
  { label = '🔄 Spieler laden', action = 'refresh' },
  { label = '❌ Schließen', action = 'close' },
}

local actionItems = {
  { label = '📍 Goto', action = 'goto' },
  { label = '📥 Bring', action = 'bring' },
  { label = '🧊 Freeze', action = 'freeze' },
  { label = '🔥 Unfreeze', action = 'unfreeze' },
  { label = '❤️ Heal / Revive', action = 'heal' },
  { label = '🦺 Armor', action = 'armor' },
  { label = '👀 Spectate', action = 'spectate' },
  { label = '🤚 Slap', action = 'slap' },
  { label = '⚠️ Warn', action = 'warn' },
  { label = '🚪 Kick', action = 'kick' },
  { label = '🔨 Ban', action = 'ban' },
  { label = '← Zurück', action = 'back' },
}

local function drawMenu()
  -- panel background
  DrawRect(0.855, 0.50, 0.27, 0.62, 10, 10, 18, 230)
  -- header bar
  DrawRect(0.855, 0.205, 0.27, 0.055, 100, 30, 40, 240)
  drawTxt(0.73, 0.188, 0.40, ('STAFFORA  ·  %s'):format(rankLabel or rankId or 'STAFF'), 255, 230, 230)

  local items = mode == 'main' and mainItems or (mode == 'players' and players or actionItems)

  if mode == 'players' then
    if #players == 0 then
      drawTxt(0.73, 0.28, 0.32, 'Keine Spieler…', 160, 160, 160)
    end
    local maxShow = 12
    local start = math.max(1, menuIndex - maxShow + 1)
    local shown = 0
    for i = start, math.min(#players, start + maxShow - 1) do
      local p = players[i]
      local y = 0.26 + shown * 0.032
      if i == menuIndex then DrawRect(0.855, y + 0.012, 0.25, 0.028, 140, 45, 50, 200) end
      local tag = p.duty and ' ★' or (p.staff and ' ·' or '')
      drawTxt(0.73, y, 0.30, ('[%s] %s%s'):format(p.id, p.name or '?', tag), 255, 255, 255)
      shown = shown + 1
    end
  elseif mode == 'actions' then
    drawTxt(0.73, 0.245, 0.30, selectedPlayer and (('[ %s ] %s'):format(selectedPlayer.id, selectedPlayer.name)) or '', 200, 180, 180)
    for i, it in ipairs(actionItems) do
      local y = 0.28 + (i - 1) * 0.030
      if i == menuIndex then DrawRect(0.855, y + 0.012, 0.25, 0.028, 140, 45, 50, 200) end
      drawTxt(0.73, y, 0.30, it.label, 255, 255, 255)
    end
  else
    for i, it in ipairs(mainItems) do
      local y = 0.26 + (i - 1) * 0.034
      if i == menuIndex then DrawRect(0.855, y + 0.014, 0.25, 0.030, 140, 45, 50, 200) end
      drawTxt(0.73, y, 0.32, it.label, 255, 255, 255)
    end
  end

  drawTxt(0.73, 0.78, 0.26, '↑↓  Enter  Backspace  ·  F9', 130, 130, 150)
end

CreateThread(function()
  while true do
    Wait(0)
    if not onDuty then
      if menuOpen then menuOpen = false end
      Wait(400)
    else
      -- F9 (control 56) or F10 (57)
      if IsControlJustPressed(0, 56) or IsControlJustPressed(0, 57) then
        menuOpen = not menuOpen
        if menuOpen then
          TriggerServerEvent('staffora:requestPlayers')
          mode = 'main'
          menuIndex = 1
        end
      end

      if menuOpen then
        drawMenu()
        local itemsCount = 1
        if mode == 'main' then itemsCount = #mainItems
        elseif mode == 'players' then itemsCount = math.max(#players, 1)
        else itemsCount = #actionItems end

        if IsControlJustPressed(0, 172) then -- up
          menuIndex = math.max(1, menuIndex - 1)
        end
        if IsControlJustPressed(0, 173) then -- down
          menuIndex = math.min(itemsCount, menuIndex + 1)
        end

        if mode == 'players' then
          if IsControlJustPressed(0, 191) and players[menuIndex] then
            selectedPlayer = players[menuIndex]
            mode = 'actions'
            menuIndex = 1
          end
          if IsControlJustPressed(0, 177) then
            mode = 'main'
            menuIndex = 1
          end
        elseif mode == 'actions' then
          if IsControlJustPressed(0, 191) and actionItems[menuIndex] then
            local a = actionItems[menuIndex]
            if a.action == 'back' then
              mode = 'players'
              menuIndex = 1
            elseif selectedPlayer then
              TriggerServerEvent('staffora:adminAction', a.action, selectedPlayer.id, 'Staff menu')
              if a.action == 'kick' or a.action == 'ban' then
                mode = 'players'
                menuIndex = 1
                TriggerServerEvent('staffora:requestPlayers')
              end
            end
          end
          if IsControlJustPressed(0, 177) then
            mode = 'players'
            menuIndex = 1
          end
        else -- main
          if IsControlJustPressed(0, 191) and mainItems[menuIndex] then
            local a = mainItems[menuIndex]
            if a.action == 'players' then
              TriggerServerEvent('staffora:requestPlayers')
              mode = 'players'
              menuIndex = 1
            elseif a.action == 'noclip' then
              TriggerServerEvent('staffora:adminAction', 'noclip', 0, '')
            elseif a.action == 'god' then
              TriggerServerEvent('staffora:adminAction', 'god', 0, '')
            elseif a.action == 'selfheal' then
              TriggerEvent('staffora:heal')
            elseif a.action == 'ids' then
              showIds = not showIds
              notify(showIds and 'IDs AN' or 'IDs AUS')
            elseif a.action == 'refresh' then
              TriggerServerEvent('staffora:requestPlayers')
              notify('Spielerliste aktualisiert')
            elseif a.action == 'close' then
              menuOpen = false
            end
          end
          if IsControlJustPressed(0, 177) then
            menuOpen = false
          end
        end
      end
    end
  end
end)

print('[Staffora] FiveM Plugin v3 client loaded.')
