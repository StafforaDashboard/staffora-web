Config = {}

-- API (set via server.cfg or Team Panel setup code)
Config.ApiUrl = GetConvar('staffora_api_url', 'https://staffora.apps.bot-hosting.cloud')
Config.SetupCode = GetConvar('staffora_setup_code', '')
Config.ApiKey = GetConvar('staffora_api_key', '')
Config.HeartbeatMs = 25000

-- Keys / commands
Config.AdminKey = 'F9'          -- open staff menu (control 56)
Config.DutyCommand = 'aduty'
Config.SupportCommand = 'support'
Config.LinkCommand = 'stafforalink'
Config.VerifyCommand = 'verify'
Config.AnnounceCommand = 'sannounce'

-- Rank display
Config.RankLabels = {
  owner = 'OWNER', headadmin = 'HEAD ADMIN', admin = 'ADMIN',
  moderator = 'MOD', supporter = 'SUPPORT', support = 'SUPPORT',
}
Config.RankColors = {
  owner = { 220, 38, 38 }, headadmin = { 239, 68, 68 }, admin = { 239, 68, 68 },
  moderator = { 96, 165, 250 }, supporter = { 52, 211, 153 }, support = { 52, 211, 153 },
}

-- Staff uniform (ADMIN vest style) applied on duty
Config.Uniforms = {
  male = {
    { component = 9,  drawable = 15, texture = 0 },
    { component = 11, drawable = 55, texture = 0 },
    { component = 8,  drawable = 15, texture = 0 },
    { component = 3,  drawable = 4,  texture = 0 },
    { component = 4,  drawable = 31, texture = 0 },
    { component = 6,  drawable = 25, texture = 0 },
  },
  female = {
    { component = 9,  drawable = 17, texture = 0 },
    { component = 11, drawable = 48, texture = 0 },
    { component = 8,  drawable = 14, texture = 0 },
    { component = 3,  drawable = 3,  texture = 0 },
    { component = 4,  drawable = 30, texture = 0 },
    { component = 6,  drawable = 25, texture = 0 },
  },
}

Config.NametagDistance = 28.0
Config.NametagScale = 0.35

-- Permissions per action (rank must have these; ranks come from API staff_sync)
-- If a rank has "all" or "*" it can do everything.
Config.ActionPerms = {
  kick     = { 'kick', 'moderation', 'all' },
  ban      = { 'ban', 'moderation', 'all' },
  warn     = { 'warn', 'moderation', 'all' },
  goto     = { 'teleport', 'all' },
  bring    = { 'teleport', 'all' },
  freeze   = { 'freeze', 'moderation', 'all' },
  unfreeze = { 'freeze', 'moderation', 'all' },
  heal     = { 'heal', 'all' },
  revive   = { 'heal', 'all' },
  spectate = { 'spectate', 'all' },
  slap     = { 'moderation', 'all' },
  armor    = { 'heal', 'all' },
  noclip   = { 'noclip', 'all' },
  god      = { 'god', 'all' },
  announce = { 'announce', 'all' },
}

Config.Track = {
  joins = true, leaves = true, chat = true, deaths = true,
  admin = true, resource = true
}
