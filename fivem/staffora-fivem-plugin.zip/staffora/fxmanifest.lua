fx_version 'cerulean'
game 'gta5'
name 'Staffora FiveM Plugin'
author 'Staffora'
description 'Staffora FiveM Plugin — auto-register, tracking, duty, F9 staff panel, commands'
version '3.0.0'
lua54 'yes'

shared_scripts { 'config.lua' }
server_scripts { 'server/main.lua' }
client_scripts { 'client/main.lua' }
