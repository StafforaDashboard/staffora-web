--[[ Staffora FiveM Plugin — Server v3 ]]

local Staffora = {
  ranks = {},
  staff = {},
  bans = {},
  config = { whitelistMode = 'open' },
  apiKey = nil
}

local DATA_FILE = 'staffora_apikey.json'

local function apiUrl(path)
  return (Config.ApiUrl or ''):gsub('/$', '') .. path
end

local function loadSavedKey()
  local raw = LoadResourceFile(GetCurrentResourceName(), DATA_FILE)
  if raw and raw ~= '' then
    local ok, data = pcall(json.decode, raw)
    if ok and data and data.apiKey and data.apiKey ~= '' then
      return data.apiKey
    end
  end
  return nil
end

local function saveKey(key)
  SaveResourceFile(GetCurrentResourceName(), DATA_FILE, json.encode({ apiKey = key, savedAt = os.time() }), -1)
end

local function currentKey()
  if Staffora.apiKey and Staffora.apiKey ~= '' then return Staffora.apiKey end
  local k = Config.ApiKey
  if k and k ~= '' then return k end
  return loadSavedKey()
end

local function httpJson(method, path, body, cb)
  local key = currentKey()
  local headers = { ['Content-Type'] = 'application/json' }
  if key and key ~= '' then headers['x-staffora-key'] = key end
  PerformHttpRequest(apiUrl(path), function(code, data, _)
    local parsed = nil
    if data and data ~= '' then
      local ok, j = pcall(json.decode, data)
      if ok then parsed = j end
    end
    if cb then cb(code or 0, parsed, data) end
  end, method, body and json.encode(body) or '', headers)
end

local function getIdentifier(src, prefix)
  for i = 0, GetNumPlayerIdentifiers(src) - 1 do
    local id = GetPlayerIdentifier(src, i)
    if id and id:sub(1, #prefix) == prefix then return id end
  end
  return nil
end

local function getLicense(src)
  return getIdentifier(src, 'license:') or getIdentifier(src, 'license2:') or ('src:' .. tostring(src))
end

local function getDiscord(src)
  local d = getIdentifier(src, 'discord:')
  if d then return d:gsub('discord:', '') end
  return nil
end

local function playerPayload(src)
  return {
    serverId = tonumber(src),
    name = GetPlayerName(src),
    license = getLicense(src),
    discord = getDiscord(src),
    ping = GetPlayerPing(src)
  }
end

local function track(eventType, payload)
  if not Config.Track then return end
  httpJson('POST', '/api/fivem/resource/event', {
    type = eventType,
    payload = payload or {},
    at = os.time()
  })
end

local function staffHasPerm(license, perm)
  local st = Staffora.staff[license]
  if not st then return false end
  local want = tostring(perm or ''):lower()
  local rid = tostring(st.rankId or ''):lower()
  if rid == 'owner' or rid == 'headadmin' or rid == 'management' then return true end

  -- permissions on member (from API) or rank
  local perms = st.permissions
  if (not perms or #perms == 0) and Staffora.ranks then
    local rank = Staffora.ranks[st.rankId] or Staffora.ranks[tostring(st.rankId)]
    if rank then perms = rank.permissions or rank.perms end
  end
  if type(perms) == 'string' then perms = { perms } end
  perms = perms or {}

  for _, p in ipairs(perms) do
    local s = tostring(p):lower()
    if s == 'all' or s == '*' or s == want then return true end
  end

  -- group aliases (Config.ActionPerms)
  local needed = Config.ActionPerms and Config.ActionPerms[perm]
  if needed then
    for _, n in ipairs(needed) do
      local nl = tostring(n):lower()
      for _, p in ipairs(perms) do
        if tostring(p):lower() == nl then return true end
      end
    end
  end

  -- moderation / teleport groups on rank
  for _, p in ipairs(perms) do
    local s = tostring(p):lower()
    if s == 'moderation' and (want == 'warn' or want == 'kick' or want == 'ban' or want == 'freeze') then return true end
    if s == 'teleport' and (want == 'goto' or want == 'bring' or want == 'teleport') then return true end
    if s == 'heal' and (want == 'heal' or want == 'revive' or want == 'armor') then return true end
  end
  return false
end

local function isStaff(src)
  local lic = getLicense(src)
  return Staffora.staff[lic] ~= nil
end

local function isOnDuty(src)
  local st = Staffora.staff[getLicense(src)]
  return st and st.duty == true
end

local function notify(src, msg)
  TriggerClientEvent('staffora:notify', src, tostring(msg))
end

local function broadcastDutyList()
  local list = {}
  for lic, st in pairs(Staffora.staff) do
    if st.duty and st.serverId then
      list[tonumber(st.serverId)] = {
        rankId = st.rankId,
        label = (Config.RankLabels and Config.RankLabels[st.rankId]) or st.rankId or 'STAFF',
        name = st.name or GetPlayerName(st.serverId) or 'Staff'
      }
    end
  end
  TriggerClientEvent('staffora:dutySync', -1, list)
end

local function applyCommands(cmds)
  if type(cmds) ~= 'table' then return end
  for _, cmd in ipairs(cmds) do
    local t = cmd.type or cmd.cmd
    if t == 'kick' and cmd.serverId then
      DropPlayer(tonumber(cmd.serverId), cmd.reason or 'Staffora')
    elseif t == 'ban' and cmd.license then
      Staffora.bans[cmd.license] = { reason = cmd.reason or 'Banned', until = cmd.until }
      for _, sid in ipairs(GetPlayers()) do
        if getLicense(sid) == cmd.license then
          DropPlayer(sid, 'Ban: ' .. (cmd.reason or 'Staffora'))
        end
      end
    elseif t == 'warn' and cmd.serverId then
      notify(tonumber(cmd.serverId), ('Warn: %s'):format(cmd.reason or ''))
    elseif t == 'announce' and cmd.message then
      TriggerClientEvent('staffora:announce', -1, tostring(cmd.message))
    elseif t == 'staff_sync' then
      if cmd.ranks then
        local map = {}
        if type(cmd.ranks) == 'table' then
          for _, r in pairs(cmd.ranks) do
            if type(r) == 'table' and r.id then
              map[r.id] = r
              map[tostring(r.id)] = r
            end
          end
        end
        if next(map) then Staffora.ranks = map end
      end
      if cmd.members then
        local byLic = {}
        local function ingestMember(lic, m)
          if not lic or type(m) ~= 'table' then return end
          local prev = Staffora.staff[lic] or {}
          local rank = Staffora.ranks[m.rankId or m.rank] or Staffora.ranks[tostring(m.rankId or m.rank or '')]
          local perms = m.permissions or (rank and (rank.permissions or rank.perms)) or prev.permissions
          byLic[lic] = {
            rankId = m.rankId or m.rank or prev.rankId,
            name = m.name or prev.name,
            discordId = m.discordId or prev.discordId,
            duty = prev.duty == true,
            serverId = prev.serverId,
            permissions = perms
          }
        end
        if cmd.members[1] then
          for _, m in ipairs(cmd.members) do
            if m.license then ingestMember(m.license, m) end
          end
        else
          for lic, m in pairs(cmd.members) do
            ingestMember(type(lic) == 'string' and lic or (m and m.license), m)
          end
        end
        for lic, st in pairs(Staffora.staff) do
          if byLic[lic] then
            byLic[lic].duty = st.duty
            byLic[lic].serverId = st.serverId
          end
        end
        Staffora.staff = byLic
      end
      broadcastDutyList()
    elseif t == 'inventory_restore' then
      TriggerEvent('staffora:inventoryRestore', cmd.license, cmd.inventory)
    end
  end
end

local function heartbeat()
  local players = {}
  for _, sid in ipairs(GetPlayers()) do
    players[#players + 1] = playerPayload(sid)
  end
  local duty = {}
  for lic, st in pairs(Staffora.staff) do
    if st.duty then duty[#duty + 1] = { license = lic, rankId = st.rankId, serverId = st.serverId } end
  end
  httpJson('POST', '/api/fivem/resource/heartbeat', {
    players = players,
    duty = duty,
    slots = GetConvarInt('sv_maxclients', 32),
    resource = GetCurrentResourceName(),
    version = '3.0.0'
  }, function(code, data)
    if code == 200 and data then
      if data.commands then applyCommands(data.commands) end

      -- ranks: array -> map by id
      if data.ranks then
        local map = {}
        if type(data.ranks) == 'table' then
          for _, r in pairs(data.ranks) do
            if type(r) == 'table' and r.id then
              map[r.id] = r
              map[tostring(r.id)] = r
            end
          end
        end
        if next(map) then Staffora.ranks = map end
      end

      -- staff: prefer array with permissions
      if data.staff then
        if type(data.staff) == 'table' then
          -- array form
          local isArray = data.staff[1] ~= nil or (data.staff[1] == nil and #data.staff > 0)
          if data.staff[1] or (type(data.staff[1]) == 'table') then
            for _, m in ipairs(data.staff) do
              if m and m.license then
                local prev = Staffora.staff[m.license] or {}
                Staffora.staff[m.license] = {
                  rankId = m.rankId or m.rank or prev.rankId,
                  name = m.name or prev.name,
                  discordId = m.discordId or prev.discordId,
                  duty = prev.duty == true,
                  serverId = prev.serverId,
                  permissions = m.permissions or prev.permissions
                }
              end
            end
          else
            -- object map license -> member
            for lic, m in pairs(data.staff) do
              if type(m) == 'table' then
                local prev = Staffora.staff[lic] or {}
                Staffora.staff[lic] = {
                  rankId = m.rankId or m.rank or prev.rankId,
                  name = m.name or prev.name,
                  discordId = m.discordId or prev.discordId,
                  duty = prev.duty == true,
                  serverId = prev.serverId,
                  permissions = m.permissions or prev.permissions
                }
              end
            end
          end
        end
      end

      if data.members and type(data.members) == 'table' then
        for lic, m in pairs(data.members) do
          if type(m) == 'table' then
            local prev = Staffora.staff[lic] or {}
            Staffora.staff[lic] = {
              rankId = m.rankId or m.rank or prev.rankId,
              name = m.name or prev.name,
              discordId = m.discordId or prev.discordId,
              duty = prev.duty == true,
              serverId = prev.serverId,
              permissions = m.permissions or prev.permissions
            }
          end
        end
      end

      if data.config then Staffora.config = data.config end
    elseif code == 401 then
      print('[Staffora] heartbeat 401 — check API key / re-register setup code')
    end
  end)
end

local function tryRegister(cb)
  local code = Config.SetupCode
  if not code or code == '' then
    Staffora.apiKey = currentKey()
    if cb then cb(Staffora.apiKey ~= nil) end
    return
  end
  httpJson('POST', '/api/fivem/resource/register', {
    setupCode = code,
    serverName = GetConvar('sv_hostname', 'FiveM'),
    resource = GetCurrentResourceName()
  }, function(status, data)
    if status == 200 and data and data.apiKey then
      Staffora.apiKey = data.apiKey
      saveKey(data.apiKey)
      print('[Staffora] Registered. API key saved.')
      if cb then cb(true) end
    else
      print('[Staffora] Register failed:', status, data and data.error or '')
      Staffora.apiKey = currentKey()
      if cb then cb(false) end
    end
  end)
end

-- Player connect
AddEventHandler('playerConnecting', function(name, setKickReason, deferrals)
  local src = source
  deferrals.defer()
  Wait(0)
  local license = getLicense(src)
  if Staffora.bans[license] then
    deferrals.done('Banned: ' .. (Staffora.bans[license].reason or 'Staffora'))
    return
  end
  deferrals.done()
end)

AddEventHandler('playerJoining', function()
  local src = source
  local license = getLicense(src)
  if Staffora.staff[license] then
    Staffora.staff[license].serverId = src
    Staffora.staff[license].name = GetPlayerName(src)
  end
  if Config.Track and Config.Track.joins then
    track('join', { player = playerPayload(src) })
  end
end)

AddEventHandler('playerDropped', function(reason)
  local src = source
  local license = getLicense(src)
  if Config.Track and Config.Track.leaves then
    track('leave', { player = playerPayload(src), reason = reason })
  end
  if Staffora.staff[license] then
    Staffora.staff[license].duty = false
    Staffora.staff[license].serverId = nil
  end
  SetTimeout(100, broadcastDutyList)
end)

AddEventHandler('chatMessage', function(src, name, msg)
  if Config.Track and Config.Track.chat then
    track('chat', { player = playerPayload(src), message = msg })
  end
end)

RegisterNetEvent('staffora:playerDied', function(killerServerId, cause)
  local src = source
  if Config.Track and Config.Track.deaths then
    track('death', {
      player = playerPayload(src),
      killer = killerServerId and playerPayload(killerServerId) or nil,
      cause = cause
    })
  end
end)

-- Duty
RegisterCommand(Config.DutyCommand or 'aduty', function(src)
  if src == 0 then return end
  local license = getLicense(src)
  local st = Staffora.staff[license]
  if not st then
    notify(src, 'Du bist kein Staff.')
    return
  end
  st.duty = not st.duty
  st.serverId = src
  st.name = GetPlayerName(src)
  TriggerClientEvent('staffora:duty', src, st.duty, st.rankId)
  notify(src, st.duty and ('Duty AN · %s · F9 Menü'):format(tostring(st.rankId)) or 'Duty AUS')
  track('duty', { license = license, duty = st.duty, rankId = st.rankId })
  broadcastDutyList()
end, false)

-- Support request
RegisterCommand(Config.SupportCommand or 'support', function(src, args)
  if src == 0 then return end
  local reason = table.concat(args or {}, ' ')
  if reason == '' then reason = 'Support benötigt' end
  httpJson('POST', '/api/fivem/resource/support', {
    player = playerPayload(src),
    reason = reason
  }, function(code)
    notify(src, code == 200 and 'Support-Anfrage gesendet.' or 'Support fehlgeschlagen.')
  end)
end, false)

-- Discord link
RegisterCommand(Config.LinkCommand or 'stafforalink', function(src, args)
  if src == 0 then return end
  local code = args[1]
  if not code then
    notify(src, 'Nutzung: /stafforalink CODE')
    return
  end
  httpJson('POST', '/api/fivem/resource/link', {
    code = code,
    license = getLicense(src),
    discord = getDiscord(src),
    name = GetPlayerName(src)
  }, function(status, data)
    if status == 200 then
      notify(src, 'Discord verknüpft!')
    else
      notify(src, (data and data.error) or 'Link fehlgeschlagen')
    end
  end)
end, false)

RegisterCommand(Config.VerifyCommand or 'verify', function(src, args)
  if src == 0 then return end
  local code = args[1]
  if not code then
    notify(src, 'Nutzung: /verify CODE')
    return
  end
  httpJson('POST', '/api/fivem/resource/verify', {
    code = code,
    license = getLicense(src),
    discord = getDiscord(src),
    name = GetPlayerName(src)
  }, function(status, data)
    if status == 200 then
      notify(src, 'Verifiziert! Discord verknüpft + Whitelist.')
    else
      notify(src, (data and data.error) or 'Verify fehlgeschlagen')
    end
  end)
end, false)

RegisterCommand(Config.AnnounceCommand or 'sannounce', function(src, args)
  if src == 0 then return end
  if not isOnDuty(src) then notify(src, 'Nur on-duty Staff.') return end
  if not staffHasPerm(getLicense(src), 'announce') then notify(src, 'Keine Berechtigung.') return end
  local msg = table.concat(args or {}, ' ')
  if msg == '' then notify(src, 'Nutzung: /sannounce Text') return end
  TriggerClientEvent('staffora:announce', -1, msg)
  track('announce', { actor = getLicense(src), message = msg })
end, false)

-- Chat shortcuts for staff on duty
local function staffCmd(name, action, needTarget)
  RegisterCommand(name, function(src, args)
    if src == 0 then return end
    if not isOnDuty(src) then notify(src, 'Duty zuerst (/aduty).') return end
    if not staffHasPerm(getLicense(src), action) then notify(src, 'Keine Berechtigung.') return end
    local target = tonumber(args[1])
    if needTarget and (not target or not GetPlayerName(target)) then
      notify(src, 'Nutzung: /' .. name .. ' [ID]')
      return
    end
    local reason = table.concat(args, ' ', needTarget and 2 or 1)
    if reason == '' then reason = 'Staff' end
    TriggerEvent('staffora:runAdmin', src, action, target, reason)
  end, false)
end

staffCmd('skick', 'kick', true)
staffCmd('sban', 'ban', true)
staffCmd('swarn', 'warn', true)
staffCmd('sgoto', 'goto', true)
staffCmd('sbring', 'bring', true)
staffCmd('sfreeze', 'freeze', true)
staffCmd('sunfreeze', 'unfreeze', true)
staffCmd('srevive', 'revive', true)
staffCmd('sheal', 'heal', true)
staffCmd('sspectate', 'spectate', true)

-- Central admin runner (menu + commands)
AddEventHandler('staffora:runAdmin', function(src, action, target, reason)
  local license = getLicense(src)
  local st = Staffora.staff[license]
  if not st or not st.duty then return end
  if not staffHasPerm(license, action) then
    notify(src, 'Keine Berechtigung für: ' .. tostring(action))
    return
  end
  reason = tostring(reason or 'Staffora')

  if action == 'noclip' or action == 'god' then
    TriggerClientEvent('staffora:selfToggle', src, action)
    track('admin_' .. action, { actor = license })
    return
  end

  if not target or not GetPlayerName(target) then
    notify(src, 'Spieler nicht gefunden.')
    return
  end

  local tLicense = getLicense(target)
  if Config.Track and Config.Track.admin then
    track('admin_' .. tostring(action), {
      player = playerPayload(target),
      actor = license,
      reason = reason
    })
  end

  if action == 'kick' then
    DropPlayer(target, 'Kick: ' .. reason)
    notify(src, 'Spieler gekickt.')
  elseif action == 'ban' then
    Staffora.bans[tLicense] = { reason = reason, by = license, at = os.time() }
    DropPlayer(target, 'Ban: ' .. reason)
    httpJson('POST', '/api/fivem/resource/event', {
      type = 'ban', player = playerPayload(target), reason = reason, actor = license
    })
    notify(src, 'Spieler gebannt.')
  elseif action == 'warn' then
    notify(target, '⚠ Warnung: ' .. reason)
    notify(src, 'Warnung gesendet.')
    httpJson('POST', '/api/fivem/resource/event', {
      type = 'warn', player = playerPayload(target), reason = reason, actor = license
    })
  elseif action == 'goto' then
    local coords = GetEntityCoords(GetPlayerPed(target))
    TriggerClientEvent('staffora:teleport', src, coords.x, coords.y, coords.z)
  elseif action == 'bring' then
    local coords = GetEntityCoords(GetPlayerPed(src))
    TriggerClientEvent('staffora:teleport', target, coords.x, coords.y, coords.z)
  elseif action == 'freeze' then
    TriggerClientEvent('staffora:freeze', target, true)
    notify(src, 'Eingefroren.')
  elseif action == 'unfreeze' then
    TriggerClientEvent('staffora:freeze', target, false)
    notify(src, 'Aufgetaut.')
  elseif action == 'revive' or action == 'heal' then
    TriggerClientEvent('staffora:heal', target)
    notify(src, 'Heal/Revive.')
  elseif action == 'spectate' then
    TriggerClientEvent('staffora:spectate', src, target)
  elseif action == 'slap' then
    TriggerClientEvent('staffora:slap', target)
  elseif action == 'armor' then
    TriggerClientEvent('staffora:armor', target)
  end
end)

RegisterNetEvent('staffora:adminAction', function(action, targetServerId, reason)
  local src = source
  TriggerEvent('staffora:runAdmin', src, action, tonumber(targetServerId), reason)
end)

RegisterNetEvent('staffora:requestPlayers', function()
  local src = source
  if not isOnDuty(src) then return end
  local list = {}
  for _, sid in ipairs(GetPlayers()) do
    local id = tonumber(sid)
    local lic = getLicense(id)
    local st = Staffora.staff[lic]
    list[#list + 1] = {
      id = id,
      name = GetPlayerName(id),
      ping = GetPlayerPing(id),
      staff = st ~= nil,
      duty = st and st.duty or false,
      rank = st and st.rankId or nil
    }
  end
  table.sort(list, function(a, b) return a.id < b.id end)
  TriggerClientEvent('staffora:playerList', src, list)
end)

RegisterNetEvent('staffora:backupInventory', function(inventory)
  local src = source
  httpJson('POST', '/api/fivem/resource/inventory-backup', {
    license = getLicense(src), inventory = inventory, reason = 'manual', by = getLicense(src)
  })
end)

AddEventHandler('staffora:inventoryRestore', function(license, inventory)
  TriggerEvent('staffora:framework:restoreInventory', license, inventory)
end)

RegisterCommand('staffora_hb', function(s)
  if s ~= 0 then return end
  heartbeat()
end, true)

RegisterCommand('staffora_status', function(s)
  if s ~= 0 then return end
  print('[Staffora] key=' .. tostring(currentKey() ~= nil) .. ' staff=' .. tostring((function()
    local n = 0
    for _ in pairs(Staffora.staff) do n = n + 1 end
    return n
  end)()) .. ' players=' .. #GetPlayers())
end, true)

CreateThread(function()
  Wait(2000)
  tryRegister(function()
    heartbeat()
  end)
  while true do
    Wait(Config.HeartbeatMs or 25000)
    heartbeat()
  end
end)

print('[Staffora] FiveM Plugin v3 server loaded.')
