# Staffora FiveM Resource

## Install
1. Copy `staffora` folder into your server `resources/`
2. In `server.cfg`:
```
set staffora_api_url "https://YOUR-STAFFORA-API"
set staffora_api_key "KEY_FROM_DASHBOARD"
ensure staffora
```
3. Dashboard → choose **FiveM** → Setup → copy API key

## Phase 1
- Heartbeat every 30s with online players
- Server status online/offline in Staffora dashboard
