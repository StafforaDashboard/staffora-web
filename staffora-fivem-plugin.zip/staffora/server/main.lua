local Staffora = { staff = {}, bans = {}, config = { whitelistMode = 'open' }, apiKey = nil }

local DATA_FILE = 'staffora_apikey.json'

local function apiUrl(path)
  return (Config.ApiUrl or ''):gsub('/$', '') .. path
end

local function loadSavedKey()
  local raw = LoadResourceFile(GetCurrentResourceName(), DATA_FILE)
  if raw and raw ~= '' then
    local ok, data = pcall(json.decode, raw)
    if ok and data and data.apiKey and data.apiKey ~= '' then
      return data.apiKey
    end
  end
  return nil
end

local function saveKey(key)
  Staffora.apiKey = key
  SaveResourceFile(GetCurrentResourceName(), DATA_FILE, json.encode({
    apiKey = key,
    savedAt = os.time()
  }), -1)
end

local function currentKey()
  if Staffora.apiKey and Staffora.apiKey ~= '' then return Staffora.apiKey end
  if Config.ApiKey and Config.ApiKey ~= '' and Config.ApiKey ~= 'CHANGE_ME' then
    return Config.ApiKey
  end
  return loadSavedKey()
end

local function httpJson(method, path, body, cb)
  local key = currentKey() or ''
  PerformHttpRequest(apiUrl(path), function(code, resp)
    local data = nil
    if resp and resp ~= '' then
      local ok, parsed = pcall(json.decode, resp)
      if ok then data = parsed end
    end
    if cb then cb(code, data, resp) end
  end, method, body and json.encode(body) or '', {
    ['Content-Type'] = 'application/json',
    ['X-Staffora-Key'] = key
  })
end

local function getLicense(src)
  for _, ident in ipairs(GetPlayerIdentifiers(src) or {}) do
    if ident:find('license:') == 1 then return ident end
  end
  return 'temp:' .. tostring(src)
end

local function getDiscord(src)
  for _, ident in ipairs(GetPlayerIdentifiers(src) or {}) do
    if ident:find('discord:') == 1 then return ident:gsub('discord:', '') end
  end
  return nil
end

local function playerPayload(src)
  return {
    serverId = src,
    name = GetPlayerName(src) or 'Unknown',
    license = getLicense(src),
    discordId = getDiscord(src),
    identifiers = GetPlayerIdentifiers(src) or {},
    ping = GetPlayerPing(src)
  }
end

local function track(eventType, payload)
  if not currentKey() then return end
  httpJson('POST', '/api/fivem/resource/event', {
    type = eventType,
    player = payload and payload.player or nil,
    name = payload and payload.name or nil,
    license = payload and payload.license or nil,
    reason = payload and payload.reason or nil,
    message = payload and payload.message or nil,
    actor = payload and payload.actor or nil,
    data = payload and payload.data or nil,
    serverId = payload and payload.serverId or nil
  })
end

local function collectPlayers()
  local list = {}
  for _, sid in ipairs(GetPlayers()) do
    local id = tonumber(sid)
    local license = getLicense(id)
    local st = Staffora.staff[license] or {}
    list[#list + 1] = {
      serverId = id,
      name = GetPlayerName(sid) or 'Unknown',
      license = license,
      discordId = getDiscord(id),
      identifiers = GetPlayerIdentifiers(sid) or {},
      ping = GetPlayerPing(sid),
      staff = st.rankId ~= nil,
      rankId = st.rankId,
      duty = st.duty == true
    }
  end
  return list
end

local function applyCommands(cmds)
  if type(cmds) ~= 'table' then return end
  for _, cmd in ipairs(cmds) do
    if cmd.type == 'kick' and cmd.license then
      for _, sid in ipairs(GetPlayers()) do
        if getLicense(tonumber(sid)) == cmd.license then
          DropPlayer(sid, ('Staffora: %s'):format(cmd.reason or 'Kicked'))
        end
      end
    elseif cmd.type == 'ban' and cmd.license then
      Staffora.bans[cmd.license] = {
        reason = cmd.reason or 'Banned',
        until_ = cmd.durationSec and (os.time() + cmd.durationSec) or 0
      }
      for _, sid in ipairs(GetPlayers()) do
        if getLicense(tonumber(sid)) == cmd.license then
          DropPlayer(sid, ('Staffora Ban: %s'):format(cmd.reason or 'Banned'))
        end
      end
    elseif cmd.type == 'unban' and cmd.license then
      Staffora.bans[cmd.license] = nil
    elseif cmd.type == 'staff_sync' and type(cmd.members) == 'table' then
      Staffora.staff = cmd.members
    elseif cmd.type == 'warn' and cmd.license then
      for _, sid in ipairs(GetPlayers()) do
        if getLicense(tonumber(sid)) == cmd.license then
          TriggerClientEvent('staffora:notify', tonumber(sid), ('Warn: %s'):format(cmd.reason or ''))
        end
      end
    elseif cmd.type == 'announce' and cmd.message then
      TriggerClientEvent('staffora:announce', -1, tostring(cmd.message))
      TriggerClientEvent('staffora:notify', -1, tostring(cmd.message))
    elseif cmd.type == 'inventory_restore' and cmd.license then
      TriggerEvent('staffora:inventoryRestore', cmd.license, cmd.inventory)
    end
  end
end

local function heartbeat()
  if not currentKey() then
    print('^1[Staffora] No API key yet — set staffora_setup_code once or wait for auto-register^0')
    return
  end
  local players = collectPlayers()
  local maxSlots = (Config.MaxSlots and Config.MaxSlots > 0) and Config.MaxSlots or GetConvarInt('sv_maxclients', 32)
  httpJson('POST', '/api/fivem/heartbeat', {
    status = 'online',
    playerCount = #players,
    maxSlots = maxSlots,
    players = players,
    uptimeSec = math.floor(GetGameTimer() / 1000),
    version = GetConvar('version', 'unknown'),
    queueCount = 0,
    maintenance = false
  }, function(code, data)
    if code ~= 200 then
      print(('[Staffora] Heartbeat HTTP %s'):format(tostring(code)))
      return
    end
    if data and data.staff then Staffora.staff = data.staff end
    if data and data.commands then applyCommands(data.commands) end
  end)
end

local function tryRegister(cb)
  local existing = currentKey()
  if existing and existing ~= '' and existing ~= 'CHANGE_ME' then
    Staffora.apiKey = existing
    if cb then cb(true) end
    return
  end
  local code = Config.SetupCode or GetConvar('staffora_setup_code', '')
  if not code or code == '' then
    print('^1[Staffora] Set convar staffora_setup_code \"XXXX\" (from Team Panel) once, then restart resource.^0')
    if cb then cb(false) end
    return
  end
  print('^3[Staffora] Registering with setup code…^0')
  PerformHttpRequest(apiUrl('/api/fivem/resource/register'), function(status, resp)
    local data = nil
    pcall(function() data = json.decode(resp or '') end)
    if status == 200 and data and data.ok and data.apiKey then
      saveKey(data.apiKey)
      print('^2[Staffora] Registered! API key saved automatically — you can remove staffora_setup_code.^0')
      if cb then cb(true) end
    else
      print('^1[Staffora] Register failed: ' .. tostring(data and data.error or status) .. '^0')
      if cb then cb(false) end
    end
  end, 'POST', json.encode({
    code = code,
    hostname = GetConvar('sv_hostname', 'FiveM'),
    endpoint = GetConvar('netPort', '')
  }), { ['Content-Type'] = 'application/json' })
end

CreateThread(function()
  Wait(2000)
  tryRegister(function(ok)
    if not ok then return end
    httpJson('GET', '/api/fivem/resource/config', nil, function(code, data)
      if code == 200 and data then
        Staffora.config.whitelistMode = data.whitelistMode or 'open'
        print('^2[Staffora] Config loaded, whitelistMode=' .. tostring(Staffora.config.whitelistMode) .. '^0')
      end
    end)
    if Config.Track and Config.Track.resource then
      track('resource_start', { data = { resource = GetCurrentResourceName() } })
    end
    httpJson('POST', '/api/fivem/resource/restart-notify', { phase = 'started' })
    print('^2[Staffora] Bridge online — tracking enabled^0')
    while true do
      heartbeat()
      Wait(Config.HeartbeatMs or 30000)
    end
  end)
end)

AddEventHandler('playerConnecting', function(name, setKickReason, deferrals)
  local src = source
  deferrals.defer()
  Wait(0)
  deferrals.update('Staffora: checking…')
  local license = nil
  for _, ident in ipairs(GetPlayerIdentifiers(src) or {}) do
    if ident:find('license:') == 1 then license = ident break end
  end
  if license and Staffora.bans[license] then
    local b = Staffora.bans[license]
    if b.until_ == 0 or b.until_ > os.time() then
      deferrals.done(('Staffora: Banned — %s'):format(b.reason or ''))
      return
    end
    Staffora.bans[license] = nil
  end
  if license and Staffora.config.whitelistMode == 'strict' then
    local done, allowed = false, false
    PerformHttpRequest(apiUrl('/api/fivem/resource/whitelist/' .. license:gsub(':', '%%3A')), function(code, resp)
      local data = nil
      pcall(function() data = json.decode(resp or '') end)
      allowed = code == 200 and data and data.whitelisted
      done = true
    end, 'GET', '', { ['X-Staffora-Key'] = currentKey() or '' })
    local n = 0
    while not done and n < 50 do Wait(100) n = n + 1 end
    if not allowed then
      deferrals.done('Staffora: Not on whitelist. Verify in Discord / Team Panel.')
      return
    end
  end
  deferrals.done()
end)

AddEventHandler('playerJoining', function()
  local src = source
  if Config.Track and Config.Track.joins then
    track('player_join', { player = playerPayload(src) })
  end
end)

AddEventHandler('playerDropped', function(reason)
  local src = source
  if Config.Track and Config.Track.leaves then
    track('player_leave', {
      player = playerPayload(src),
      reason = reason
    })
  end
  Wait(50)
end)

AddEventHandler('chatMessage', function(src, author, text)
  if Config.Track and Config.Track.chat and src and src > 0 then
    track('chat', {
      player = playerPayload(src),
      message = tostring(text or ''):sub(1, 200)
    })
  end
end)

RegisterNetEvent('staffora:playerDied', function(killerServerId, cause)
  local src = source
  if not (Config.Track and Config.Track.deaths) then return end
  track('player_death', {
    player = playerPayload(src),
    data = { killer = killerServerId, cause = cause }
  })
end)

local function broadcastDutyList()
  local list = {}
  for _, sid in ipairs(GetPlayers()) do
    local id = tonumber(sid)
    local lic = getLicense(id)
    local st = Staffora.staff[lic]
    if st and st.duty and st.rankId then
      list[#list + 1] = { id = id, name = GetPlayerName(sid) or 'Staff', rankId = st.rankId }
    end
  end
  TriggerClientEvent('staffora:dutySync', -1, list)
end

RegisterCommand(Config.DutyCommand or 'aduty', function(src)
  if src == 0 then return end
  local license = getLicense(src)
  local st = Staffora.staff[license]
  if not st or not st.rankId then
    TriggerClientEvent('staffora:notify', src, 'Du bist kein Staff.')
    return
  end
  local newDuty = not st.duty
  st.duty = newDuty
  Staffora.staff[license] = st
  httpJson('POST', '/api/fivem/resource/duty', { license = license, duty = newDuty, rankId = st.rankId })
  TriggerClientEvent('staffora:duty', src, newDuty, st.rankId)
  TriggerClientEvent('staffora:notify', src, newDuty and ('Duty AN · %s · F9 Menü'):format(tostring(st.rankId)) or 'Duty AUS')
  if Config.Track and Config.Track.admin then
    track(newDuty and 'duty_on' or 'duty_off', { player = playerPayload(src) })
  end
  broadcastDutyList()
end, false)

RegisterCommand(Config.SupportCommand or 'support', function(src, args)
  if src == 0 then return end
  local msg = table.concat(args or {}, ' ')
  if msg == '' then msg = 'Hilfe benötigt' end
  httpJson('POST', '/api/fivem/resource/support', {
    license = getLicense(src), name = GetPlayerName(src), serverId = src, message = msg
  }, function(code)
    TriggerClientEvent('staffora:notify', src, code == 200 and 'Support-Anfrage gesendet.' or 'Support fehlgeschlagen.')
  end)
end, false)

RegisterCommand(Config.LinkCommand or 'stafforalink', function(src, args)
  if src == 0 then return end
  local code = args[1]
  if not code then
    TriggerClientEvent('staffora:notify', src, 'Nutzung: /stafforalink CODE')
    return
  end
  httpJson('POST', '/api/fivem/resource/link', {
    code = code, license = getLicense(src), name = GetPlayerName(src)
  }, function(codeHttp, data)
    if codeHttp == 200 and data and data.ok then
      TriggerClientEvent('staffora:notify', src, 'Discord verknüpft!')
      track('discord_link', { player = playerPayload(src) })
    else
      TriggerClientEvent('staffora:notify', src, (data and data.error) or 'Link fehlgeschlagen')
    end
  end)
end, false)

RegisterCommand(Config.VerifyCommand or 'verify', function(src, args)
  if src == 0 then return end
  local code = args[1]
  if not code then
    TriggerClientEvent('staffora:notify', src, 'Nutzung: /verify CODE (Code aus Discord/Team Panel)')
    return
  end
  httpJson('POST', '/api/fivem/resource/verify', {
    code = code,
    player = playerPayload(src),
    license = getLicense(src),
    name = GetPlayerName(src)
  }, function(codeHttp, data)
    if codeHttp == 200 and data and data.ok then
      TriggerClientEvent('staffora:notify', src, 'Verifiziert! Discord verknüpft + Whitelist.')
    else
      TriggerClientEvent('staffora:notify', src, (data and data.error) or 'Verify fehlgeschlagen')
    end
  end)
end, false)

RegisterCommand('stafforaqueue', function(src, args)
  if src == 0 then return end
  local sub = args[1] or 'status'
  local license = getLicense(src)
  if sub == 'join' then
    httpJson('POST', '/api/fivem/resource/queue/join', {
      license = license, name = GetPlayerName(src), discordId = getDiscord(src)
    }, function(code, data)
      if data and data.ok then
        TriggerClientEvent('staffora:notify', src, ('Queue %s / %s'):format(tostring(data.position), tostring(data.total)))
      else
        TriggerClientEvent('staffora:notify', src, (data and data.error) or 'Queue Fehler')
      end
    end)
  elseif sub == 'leave' then
    httpJson('POST', '/api/fivem/resource/queue/leave', { license = license }, function()
      TriggerClientEvent('staffora:notify', src, 'Queue verlassen')
    end)
  else
    httpJson('GET', '/api/fivem/resource/queue/position/' .. license:gsub(':', '%%3A'), nil, function(code, data)
      if data and data.position then
        TriggerClientEvent('staffora:notify', src, ('Position %s / %s'):format(tostring(data.position), tostring(data.total)))
      else
        TriggerClientEvent('staffora:notify', src, 'Nicht in Queue')
      end
    end)
  end
end, false)

RegisterNetEvent('staffora:adminAction', function(action, targetServerId, reason)
  local src = source
  local license = getLicense(src)
  local st = Staffora.staff[license]
  if not st or not st.duty then return end
  local target = tonumber(targetServerId)
  if not target or not GetPlayerName(target) then return end
  reason = tostring(reason or 'Staffora')
  local tLicense = getLicense(target)
  if Config.Track and Config.Track.admin then
    track('admin_' .. tostring(action), {
      player = playerPayload(target),
      actor = license,
      reason = reason
    })
  end
  if action == 'kick' then
    DropPlayer(target, 'Kick: ' .. reason)
    httpJson('POST', '/api/fivem/resource/event', {
      type = 'kick', player = playerPayload(target), reason = reason, actor = license
    })
  elseif action == 'goto' then
    local coords = GetEntityCoords(GetPlayerPed(target))
    TriggerClientEvent('staffora:teleport', src, coords.x, coords.y, coords.z)
  elseif action == 'bring' then
    local coords = GetEntityCoords(GetPlayerPed(src))
    TriggerClientEvent('staffora:teleport', target, coords.x, coords.y, coords.z)
  elseif action == 'freeze' then
    TriggerClientEvent('staffora:freeze', target, true)
  elseif action == 'unfreeze' then
    TriggerClientEvent('staffora:freeze', target, false)
  elseif action == 'revive' or action == 'heal' then
    TriggerClientEvent('staffora:heal', target)
  elseif action == 'spectate' then
    TriggerClientEvent('staffora:spectate', src, target)
  end
end)

RegisterNetEvent('staffora:requestPlayers', function()
  local src = source
  local list = {}
  for _, sid in ipairs(GetPlayers()) do
    list[#list + 1] = { id = tonumber(sid), name = GetPlayerName(sid), ping = GetPlayerPing(sid) }
  end
  TriggerClientEvent('staffora:playerList', src, list)
end)

AddEventHandler('playerDropped', function()
  Wait(100)
  broadcastDutyList()
end)

RegisterNetEvent('staffora:backupInventory', function(inventory)
  local src = source
  httpJson('POST', '/api/fivem/resource/inventory-backup', {
    license = getLicense(src), inventory = inventory, reason = 'manual', by = getLicense(src)
  })
end)

AddEventHandler('staffora:inventoryRestore', function(license, inventory)
  TriggerEvent('staffora:framework:restoreInventory', license, inventory)
end)

RegisterCommand('staffora_hb', function(s)
  if s ~= 0 then return end
  heartbeat()
end, true)
