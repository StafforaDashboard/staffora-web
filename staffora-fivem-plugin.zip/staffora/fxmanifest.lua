fx_version 'cerulean'
game 'gta5'
name 'Staffora FiveM Plugin'
author 'Staffora'
description 'Staffora FiveM Plugin — install once, auto-register, full tracking, staff tools'
version '2.0.0'
lua54 'yes'

shared_scripts { 'config.lua' }
server_scripts { 'server/main.lua' }
client_scripts { 'client/main.lua' }
