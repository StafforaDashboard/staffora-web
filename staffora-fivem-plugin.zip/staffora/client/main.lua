local onDuty = false
local rankId = nil
local rankLabel = nil
local menuOpen = false
local players = {}
local frozen = false
local spectating = false
local noclip = false
local savedClothes = nil
local dutyStaff = {} -- [serverId] = { name, rankId, label }

local function notify(msg)
  BeginTextCommandThefeedDisplay('STRING')
  AddTextComponentSubstringPlayerName(tostring(msg or ''))
  EndTextCommandThefeedDisplayTicker(false, true)
end

RegisterNetEvent('staffora:notify', function(msg)
  notify(msg)
end)

local function isMalePed(ped)
  return GetEntityModel(ped) == GetHashKey('mp_m_freemode_01')
end

local function saveClothes(ped)
  savedClothes = {}
  for c = 0, 11 do
    savedClothes[c] = {
      drawable = GetPedDrawableVariation(ped, c),
      texture = GetPedTextureVariation(ped, c),
      palette = GetPedPaletteVariation(ped, c),
    }
  end
end

local function restoreClothes(ped)
  if not savedClothes then return end
  for c, d in pairs(savedClothes) do
    SetPedComponentVariation(ped, c, d.drawable, d.texture, d.palette or 0)
  end
  savedClothes = nil
end

local function applyStaffUniform(ped)
  if not DoesEntityExist(ped) then return end
  saveClothes(ped)
  local set = isMalePed(ped) and Config.Uniforms.male or Config.Uniforms.female
  for _, piece in ipairs(set or {}) do
    SetPedComponentVariation(ped, piece.component, piece.drawable, piece.texture or 0, 0)
  end
end

local function labelForRank(rank)
  if not rank then return 'STAFF' end
  local key = string.lower(tostring(rank)):gsub('%s+', '')
  return (Config.RankLabels and Config.RankLabels[key]) or string.upper(tostring(rank))
end

local function colorForRank(rank)
  local key = string.lower(tostring(rank or '')):gsub('%s+', '')
  local c = Config.RankColors and Config.RankColors[key]
  if c then return c[1], c[2], c[3] end
  return 239, 68, 68
end

RegisterNetEvent('staffora:duty', function(duty, rank)
  onDuty = duty and true or false
  rankId = rank
  rankLabel = labelForRank(rank)
  local ped = PlayerPedId()
  if onDuty then
    applyStaffUniform(ped)
    SetEntityInvincible(ped, true)
    notify(('Duty AN · %s · F9 = Staff Menü'):format(rankLabel))
  else
    menuOpen = false
    noclip = false
    SetEntityInvincible(ped, false)
    SetEntityCollision(ped, true, true)
    restoreClothes(ped)
    notify('Duty AUS · Outfit wiederhergestellt')
  end
end)

-- Other staff duty markers for nametags
RegisterNetEvent('staffora:dutySync', function(list)
  dutyStaff = {}
  for _, e in ipairs(list or {}) do
    if e.id then
      dutyStaff[tonumber(e.id)] = {
        name = e.name,
        rankId = e.rankId,
        label = labelForRank(e.rankId),
      }
    end
  end
end)

RegisterNetEvent('staffora:teleport', function(x, y, z)
  local ped = PlayerPedId()
  SetEntityCoords(ped, x + 0.0, y + 0.0, z + 0.0, false, false, false, false)
end)

RegisterNetEvent('staffora:freeze', function(state)
  frozen = state and true or false
  FreezeEntityPosition(PlayerPedId(), frozen)
end)

RegisterNetEvent('staffora:heal', function()
  local ped = PlayerPedId()
  SetEntityHealth(ped, GetEntityMaxHealth(ped))
  ClearPedBloodDamage(ped)
  SetPedArmour(ped, 100)
end)

RegisterNetEvent('staffora:spectate', function(targetId)
  local tid = GetPlayerFromServerId(tonumber(targetId))
  if tid == -1 then return end
  local tped = GetPlayerPed(tid)
  if not DoesEntityExist(tped) then return end
  spectating = not spectating
  if spectating then
    NetworkSetInSpectatorMode(true, tped)
  else
    NetworkSetInSpectatorMode(false, PlayerPedId())
  end
end)

RegisterNetEvent('staffora:playerList', function(list)
  players = list or {}
end)

local function drawTxt(x, y, scale, text, r, g, b)
  SetTextFont(4)
  SetTextScale(scale, scale)
  SetTextColour(r or 255, g or 255, b or 255, 230)
  SetTextOutline()
  SetTextCentre(false)
  BeginTextCommandDisplayText('STRING')
  AddTextComponentSubstringPlayerName(text)
  EndTextCommandDisplayText(x, y)
end

local function drawText3D(x, y, z, text, r, g, b)
  local onScreen, sx, sy = World3dToScreen2d(x, y, z)
  if not onScreen then return end
  local cam = GetGameplayCamCoords()
  local dist = #(cam - vector3(x, y, z))
  local scale = (Config.NametagScale or 0.35) / math.max(dist * 0.12, 0.4)
  SetTextScale(scale, scale)
  SetTextFont(4)
  SetTextProportional(true)
  SetTextColour(r or 239, g or 68, b or 68, 255)
  SetTextOutline()
  SetTextCentre(true)
  BeginTextCommandDisplayText('STRING')
  AddTextComponentSubstringPlayerName(text)
  EndTextCommandDisplayText(sx, sy)
end

-- Nametags: rank on "back" style above head for duty staff
CreateThread(function()
  while true do
    local sleep = 500
    local myPed = PlayerPedId()
    local myCoords = GetEntityCoords(myPed)
    local maxDist = Config.NametagDistance or 25.0

    -- self nametag when on duty
    if onDuty then
      sleep = 0
      local c = GetEntityCoords(myPed)
      local r, g, b = colorForRank(rankId)
      drawText3D(c.x, c.y, c.z + 1.15, rankLabel or 'STAFF', r, g, b)
    end

    for sid, info in pairs(dutyStaff) do
      local player = GetPlayerFromServerId(sid)
      if player ~= -1 then
        local ped = GetPlayerPed(player)
        if DoesEntityExist(ped) and ped ~= myPed then
          local c = GetEntityCoords(ped)
          if #(myCoords - c) < maxDist then
            sleep = 0
            local r, g, b = colorForRank(info.rankId)
            drawText3D(c.x, c.y, c.z + 1.15, info.label or 'STAFF', r, g, b)
            drawText3D(c.x, c.y, c.z + 1.0, info.name or '', 220, 220, 220)
          end
        end
      end
    end
    Wait(sleep)
  end
end)

-- Noclip loop
CreateThread(function()
  while true do
    Wait(0)
    if noclip and onDuty then
      local ped = PlayerPedId()
      local c = GetEntityCoords(ped)
      local speed = IsControlPressed(0, 21) and 3.0 or 1.2
      SetEntityVelocity(ped, 0.0, 0.0, 0.0)
      local fwd = GetEntityForwardVector(ped)
      if IsControlPressed(0, 32) then c = c + fwd * speed end
      if IsControlPressed(0, 33) then c = c - fwd * speed end
      if IsControlPressed(0, 22) then c = vector3(c.x, c.y, c.z + speed * 0.6) end
      if IsControlPressed(0, 36) then c = vector3(c.x, c.y, c.z - speed * 0.6) end
      SetEntityCoordsNoOffset(ped, c.x, c.y, c.z, true, true, true)
    else
      Wait(200)
    end
  end
end)

-- Full staff menu
local menuIndex = 1
local mode = 'main'
local selectedPlayer = nil

local mainItems = {
  { label = '👥 Online Spieler', action = 'players' },
  { label = '👻 Noclip Toggle', action = 'noclip' },
  { label = '🛡️ Godmode (Duty)', action = 'god' },
  { label = '❤️ Self Heal', action = 'selfheal' },
  { label = '📍 TP Waypoint', action = 'tpwp' },
  { label = 'ℹ️ Support Info', action = 'info' },
  { label = '🔴 Duty beenden', action = 'offduty' },
}

local actionItems = {
  { label = 'Goto', action = 'goto' },
  { label = 'Bring', action = 'bring' },
  { label = 'Freeze', action = 'freeze' },
  { label = 'Unfreeze', action = 'unfreeze' },
  { label = 'Heal / Revive', action = 'heal' },
  { label = 'Spectate', action = 'spectate' },
  { label = 'Kick', action = 'kick' },
  { label = '← Zurück', action = 'back' },
}

local function drawMenu()
  DrawRect(0.86, 0.48, 0.26, 0.58, 8, 8, 16, 210)
  DrawRect(0.86, 0.22, 0.26, 0.06, 120, 40, 40, 220)
  drawTxt(0.74, 0.20, 0.42, ('STAFFORA  ·  %s'):format(rankLabel or rankId or 'STAFF'), 255, 220, 220)
  local items = mode == 'main' and mainItems or (mode == 'players' and players or actionItems)
  if mode == 'players' then
    if #players == 0 then
      drawTxt(0.74, 0.30, 0.34, 'Keine Spieler…', 180, 180, 180)
    end
    for i, p in ipairs(players) do
      local y = 0.28 + (i - 1) * 0.034
      if i == menuIndex then DrawRect(0.86, y + 0.014, 0.24, 0.030, 140, 50, 50, 180) end
      drawTxt(0.74, y, 0.33, ('[%s] %s'):format(p.id, p.name or '?'), 255, 255, 255)
    end
  elseif mode == 'actions' then
    drawTxt(0.74, 0.26, 0.32, selectedPlayer and selectedPlayer.name or '', 200, 200, 200)
    for i, it in ipairs(actionItems) do
      local y = 0.30 + (i - 1) * 0.034
      if i == menuIndex then DrawRect(0.86, y + 0.014, 0.24, 0.030, 140, 50, 50, 180) end
      drawTxt(0.74, y, 0.33, it.label, 255, 255, 255)
    end
  else
    for i, it in ipairs(mainItems) do
      local y = 0.28 + (i - 1) * 0.036
      if i == menuIndex then DrawRect(0.86, y + 0.014, 0.24, 0.032, 140, 50, 50, 180) end
      drawTxt(0.74, y, 0.34, it.label, 255, 255, 255)
    end
  end
  drawTxt(0.74, 0.74, 0.28, '↑↓ · Enter · Backspace', 140, 140, 160)
end

CreateThread(function()
  while true do
    Wait(0)
    if not onDuty then
      Wait(400)
      goto continue
    end

    if IsControlJustPressed(0, 56) or IsControlJustPressed(0, 344) then
      menuOpen = not menuOpen
      if menuOpen then
        TriggerServerEvent('staffora:requestPlayers')
        mode = 'main'
        menuIndex = 1
      end
    end

    if menuOpen then
      drawMenu()
      local itemsCount = mode == 'main' and #mainItems or (mode == 'players' and math.max(#players, 1) or #actionItems)
      if IsControlJustPressed(0, 172) then menuIndex = math.max(1, menuIndex - 1) end
      if IsControlJustPressed(0, 173) then menuIndex = math.min(itemsCount, menuIndex + 1) end

      if mode == 'players' then
        if IsControlJustPressed(0, 191) and players[menuIndex] then
          selectedPlayer = players[menuIndex]
          mode = 'actions'
          menuIndex = 1
        end
        if IsControlJustPressed(0, 177) then mode = 'main' menuIndex = 1 end
      elseif mode == 'actions' then
        if IsControlJustPressed(0, 191) then
          local a = actionItems[menuIndex]
          if a.action == 'back' then
            mode = 'players'
            menuIndex = 1
          elseif selectedPlayer then
            TriggerServerEvent('staffora:adminAction', a.action, selectedPlayer.id, 'Staff menu')
            notify(a.label .. ' → ' .. (selectedPlayer.name or ''))
          end
        end
        if IsControlJustPressed(0, 177) then mode = 'players' menuIndex = 1 end
      else
        if IsControlJustPressed(0, 191) then
          local a = mainItems[menuIndex].action
          if a == 'players' then
            TriggerServerEvent('staffora:requestPlayers')
            mode = 'players'
            menuIndex = 1
          elseif a == 'noclip' then
            noclip = not noclip
            local ped = PlayerPedId()
            SetEntityCollision(ped, not noclip, not noclip)
            SetEntityInvincible(ped, noclip or onDuty)
            notify(noclip and 'Noclip AN' or 'Noclip AUS')
          elseif a == 'god' then
            local ped = PlayerPedId()
            local inv = GetPlayerInvincible(PlayerId())
            SetEntityInvincible(ped, not inv)
            notify(not inv and 'Godmode AN' or 'Godmode AUS')
          elseif a == 'selfheal' then
            TriggerEvent('staffora:heal')
            notify('Geheilt')
          elseif a == 'tpwp' then
            local blip = GetFirstBlipInfoId(8)
            if DoesBlipExist(blip) then
              local c = GetBlipInfoIdCoord(blip)
              local z = c.z
              for i = 1, 500 do
                local found, gz = GetGroundZFor_3dCoord(c.x, c.y, i + 0.0, false)
                if found then z = gz break end
              end
              SetEntityCoords(PlayerPedId(), c.x, c.y, z + 1.0, false, false, false, false)
              notify('Zum Waypoint')
            else
              notify('Kein Waypoint')
            end
          elseif a == 'offduty' then
            ExecuteCommand(Config.DutyCommand or 'aduty')
            menuOpen = false
          elseif a == 'info' then
            notify('Spieler: /support · Link: /stafforalink CODE · Panel: staffora.info/choose.html')
          end
        end
        if IsControlJustPressed(0, 177) then menuOpen = false end
      end
    end
    ::continue::
  end
end)


RegisterNetEvent('staffora:announce', function(msg)
  BeginTextCommandThefeedDisplay('STRING')
  AddTextComponentSubstringPlayerName('~b~[Staffora]~s~ ' .. tostring(msg or ''))
  EndTextCommandThefeedDisplayTicker(false, true)
  -- big notify
  SetNotificationTextEntry('STRING')
  AddTextComponentSubstringPlayerName(tostring(msg or ''))
  DrawNotification(false, true)
end)

-- Death tracking
CreateThread(function()
  local wasDead = false
  while true do
    Wait(500)
    local ped = PlayerPedId()
    local dead = IsEntityDead(ped) or IsPedDeadOrDying(ped, true)
    if dead and not wasDead then
      wasDead = true
      local killer = GetPedSourceOfDeath(ped)
      local kid = -1
      if killer and DoesEntityExist(killer) and IsPedAPlayer(killer) then
        kid = GetPlayerServerId(NetworkGetPlayerIndexFromPed(killer))
      end
      TriggerServerEvent('staffora:playerDied', kid, GetPedCauseOfDeath(ped))
    elseif not dead then
      wasDead = false
    end
  end
end)
