Staffora Dashboard — GitHub Pages ONLY
Live: https://stafforadashboard.github.io/staffora-web/
OAuth: https://stafforadashboard.github.io/staffora-web/oauth/callback.html
